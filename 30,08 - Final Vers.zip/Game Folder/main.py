import time

import pygame
from pygame import *
from pygame import mixer
from math import *
import random
import os

init()

# window
screendim = [1440, 810]
screen = display.set_mode((screendim[0], screendim[1]))
display.set_caption('SLIPPERY 7')
display.set_icon(image.load(r'Sprites\game_icon.jpg'))


# colours
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
yellow = (255, 255, 0)
grey = (120, 120, 120)
black = (0, 0, 0)
blue = (50, 150, 200)

# Background
background = transform.scale(image.load(r'Sprites\\' + 'Background' + '.png'), (screendim[0], screendim[1])).convert()


# Map
class Map:
    def __init__(self, m, rect_dim):
        self.m = m
        self.tile_dict = {}
        self.next_level = False

        for element in m:
            if element != ' ':
                self.tile_dict[element] = ([], [])

        for y, line in enumerate(self.m.splitlines()):  # Converts string grid into grid of pygame Rect class
            for x, c in enumerate(line):
                try:
                    self.tile_dict[c][0].append(Rect(x * rect_dim[0], y * rect_dim[1], rect_dim[0], rect_dim[1]))
                    sprite = transform.scale(image.load(r'Sprites\Tiles\\' + c + '.png'), (rect_dim[0], rect_dim[1]))
                    # Loads corresponding image for each Rect
                    self.tile_dict[c][1].append(sprite)

                except:
                    pass

    def blit_tiles(self):
        for key in self.tile_dict:
            for i, sprite in enumerate(self.tile_dict[key][1]):
                if key != 'f':  # 'f' refers to an empty space that Enemies can spawn
                    screen.blit(sprite, (self.tile_dict[key][0][i][0], self.tile_dict[key][0][i][1]))

    def collision_test(self, rect):  # Checks for collision between 'rect' entry and all tiles in self.tile_dict
        collisions = []

        for key in self.tile_dict:
            for i, tile in enumerate(self.tile_dict[key][0]):
                if rect.colliderect(tile):
                    collisions.append([key, i])
        return collisions  # returns any collisions that occurred

    def collision_reaction(self, collisions, object, axis):
        # Determines reaction between colliding object and specific tile
        self.next_level = False
        for collision in collisions:
            # 'collision' in format [dict key], placement in grid
            key = collision[0]
            i = collision[1]
            tile = self.tile_dict[key][0]

            if key == "h":  # if object collides with 'hole'
                object.take_damage(999)

            if key == "s":  # if object collides with 'spikes'
                if not object.invulnerable:
                    object.take_damage(10)

            if key == "t":  # if object collides with 'tile' (Solid block)
                # movement is separated into x and y-axis 0 = x, 1 = y
                if axis == 0:
                    #  if a collision occurs in the x-axis, object must be moving either left or right
                    if object.movement[0] > 0:  # if object is moving right, they must be colliding left side of tile
                        object.rect.right = tile[i].left  # sets object back to left side of tile
                    if object.movement[0] < 0:
                        object.rect.left = tile[i].right

                elif axis == 1:
                    if object.movement[1] > 0:
                        object.rect.bottom = tile[i].top
                    if object.movement[1] < 0:
                        object.rect.top = tile[i].bottom

            if key == "e":  # if object collides with 'exit'
                self.next_level = True

    def boundaries(self, rect):  # Stops rect from leaving set boundaries
        xrange = [170, 1235]
        yrange = [90, 647]
        # if rect is outside of boundaries, set rect coordinates back inside boundaries
        if rect.x > xrange[1]:
            rect.x = xrange[1]

        elif rect.x < xrange[0]:
            rect.x = xrange[0]

        if rect.y > yrange[1]:
            rect.y = yrange[1]

        elif rect.y < yrange[0]:
            rect.y = yrange[0]


# Entity
class Entity:
    def __init__(self, hp, sprite_dir, dim, spd):
        # dim is in form [hit box rect dim x, hit box rect dim y, sprite rect dim x, sprite rect dim y]
        self.hp = hp

        self.rect = Rect(0, 0, dim[0], dim[1])
        self.movement = [0, 0]
        self.spd = spd
        self.max_spd = spd

        self.frame = 0  # determines which animation frame Entity is on
        self.animations = {}
        self.animation_speed = 0.1  # determines cycle speed of animation frames
        self.animation_state = ''  # determines which folder to take animation frame from
        self.invulnerable = True
        self.invulnerable_duration = 30  # number of frames that entity cannot take damage

        self.hp_bar = Rect(0, 0, hp, self.rect[3]/5)  # used to display current hp
        self.hp_bar_vfx = Rect(0, 0, hp, self.rect[3]/5)  # used to visualize amount of damage taken

        self.knock_back = False

        for folder in os.listdir(sprite_dir):  # opens animation folder using 'sprite_directory'
            self.animations[folder] = []
            for frame in os.listdir(sprite_dir + folder):
                rendered_image = transform.scale(image.load(sprite_dir + folder + '\\' + frame),
                                                 (dim[2], dim[3]))

                self.animations[folder].append(rendered_image)  # append frames in order of name

    def animate(self, frame_speed, offset):  # used to cycle between, and load current animation frame
        self.frame += frame_speed
        if int(self.frame) >= len(self.animations[self.animation_state]):
            # if object has cycled through every frame: reset to first frame
            self.frame = 0

        screen.blit(self.animations[self.animation_state][int(self.frame)],
                    (self.rect[0] + offset[0], self.rect[1] + offset[1]))

    def take_damage(self, amount):  # reduce the Entities' hp by 'amount'
        self.hp -= amount
        self.invulnerable = True  # prevents Entity from taking damage every frame
        if self.hp <= 0:  # if Entity dies, reset frame to play full death animation
            self.frame = 0

    def invulnerable_timer(self):  # counts down the amount of frames before Entity can take damage
        if self.invulnerable:
            self.invulnerable_duration -= 1

        if self.invulnerable_duration <= 0:
            self.invulnerable_duration = 30
            self.invulnerable = False

    def find_theta(self, other):  # finds angle, in terms of radiance 'other' is relative to Entity
        deltax = (other.rect.centerx - self.rect.centerx)
        deltay = (other.rect.centery - self.rect.centery)

        if deltax == 0:  # prevents zero division error
            deltax += 1
        if deltay == 0:
            deltay += 1

        self.theta = atan2(deltax, -deltay)  # trig
        self.theta %= 2 * pi

    def take_knock_back(self):
        # reverses the 'movement' of the Entity, opposite from 'find_theta' direction
        self.movement[0] = (self.spd * sin(self.theta)) * -1
        self.movement[1] = (-self.spd * cos(self.theta)) * -1

        self.spd -= 0.3  # causes Entity to slow down and come to a stop after taking knock back
        if self.spd <= 0:
            self.knock_back = False
            self.spd = self.max_spd

    def health_bar(self, pos, colour):  # loads health bar, given position and colour
        self.hp_bar[2] = self.hp
        self.hp_bar.centerx, self.hp_bar.centery = pos[0], pos[1]
        self.hp_bar_vfx.centerx, self.hp_bar_vfx.centery = pos[0], pos[1]

        if self.hp_bar_vfx[2] > self.hp_bar[2]:  # Equalizes 'hp_bar_vfx' and 'hp_bar'
            self.hp_bar_vfx[2] -= 0.05

        draw.rect(screen, yellow, self.hp_bar_vfx)
        draw.rect(screen, colour, self.hp_bar)


# Player
class Player(Entity):  # Child class of 'Entity', used for playable character
    def __init__(self, hp, sprite_dir, dim, spd):
        super().__init__(hp, sprite_dir, dim, spd)

        self.rect[0], self.rect[1] = 700, 650
        self.left, self.right, self.up, self.down = False, False, False, False
        self.facing = 'backward'  # defines which direction player is facing
        self.dodging = False  # defines if player is in 'dodging' state

        self.animation_state = 'idle_backward'
        self.death_sound = mixer.Sound(r'Sounds\Player\death_sound.wav')

    def move(self, m, enemies):
        # Used to control Player movement, when accounting for collisions with borders, Enemies, and Map tiles
        if self.hp > 0:  # only runs if Player is still alive (dead player cannot move)
            if not self.dodging and not self.knock_back:  # standard movement using keyboard controls

                self.movement = [0, 0]

                if self.right:
                    self.movement[0] += self.spd  # defines movement based on which direction state Player is in
                if self.left:
                    self.movement[0] -= self.spd
                if self.up:
                    self.movement[1] -= self.spd
                if self.down:
                    self.movement[1] += self.spd

            elif self.dodging and not self.knock_back:  # movement if Player is in 'dodging' state
                self.dodge(m)

            elif self.knock_back:  # movement if Player is in 'knock_back' state
                self.take_knock_back()

            for x in range(2):  # moves player
                m.boundaries(self.rect)
                self.rect[x] += self.movement[x]
                collisions = m.collision_test(self.rect)
                m.collision_reaction(collisions, self, x)  # for each axis, moves player and checks for collisions

            self.player_enemy_collision(enemies)

        self.invulnerable_timer()
        self.direction()
        self.animate(self.animation_speed, [0, -24])
        self.health_bar([self.rect.centerx, self.rect[1] - 24], green)

    def player_enemy_collision(self, enemies):  # checks for collision between Player and all Enemies
        for enemy in enemies:
            if self.rect.colliderect(enemy.rect) and not self.invulnerable and enemy.hp > 0:
                # Player collides with enemy, and Player is not invulnerable, and Enemy is not dead
                self.spd = enemy.knock_back_pwr
                self.find_theta(enemy)
                self.knock_back = True
                self.take_damage(enemy.dmg)

    def direction(self):  # used to get animation states, as well as facing states
        if self.hp <= 0:
            self.animation_state = 'death'
            self.animation_speed = 0.2

        if self.animation_state != 'death':
            if self.movement[0] > 0:
                self.facing = 'right'
            elif self.movement[0] < 0:
                self.facing = 'left'
            elif self.movement[1] > 0 and self.movement[0] == 0:
                self.facing = 'forward'
            elif self.movement[1] < 0 and self.movement[0] == 0:
                self.facing = 'backward'

            if self.dodging:
                self.animation_speed = 0.3
                if self.facing == 'right':
                    self.animation_state = 'dodge_right'
                elif self.facing == 'left':
                    self.animation_state = 'dodge_left'
                elif self.facing == 'forward':
                    self.animation_state = 'dodge_forward'
                elif self.facing == 'backward':
                    self.animation_state = 'dodge_backward'

            elif self.movement == [0, 0]:
                self.animation_speed = 0.1
                if self.facing == 'right':
                    self.animation_state = 'idle_right'
                elif self.facing == 'left':
                    self.animation_state = 'idle_left'
                elif self.facing == 'forward':
                    self.animation_state = 'idle_forward'
                elif self.facing == 'backward':
                    self.animation_state = 'idle_backward'

            else:
                self.animation_speed = 0.1
                if self.facing == 'right':
                    self.animation_state = 'walk_right'
                elif self.facing == 'left':
                    self.animation_state = 'walk_left'
                elif self.facing == 'forward':
                    self.animation_state = 'walk_forward'
                elif self.facing == 'backward':
                    self.animation_state = 'walk_backward'

    def dodge(self, m):  # puts player in an invulnerable dodge state for a set duration
        if self.invulnerable and self.movement != [0, 0]:
            # only allows player to dodge while invulnerable and moving in any direction
            if self.movement[0] == 0 or self.movement[1] == 0:
                # if Player is dodging in 1 axis increase the dodge speed for single axis
                for i in range(2):
                    self.rect[i] += self.movement[i] * 1.5
                    collisions = m.collision_test(self.rect)
                    m.collision_reaction(collisions, self, i)
                    m.boundaries(self.rect)
            else:
                for i in range(2):
                    # if Player is dodging in 2 axis, they will travel ~twice the distance of 1 axis (a^2 + b^2 = c^2)
                    # therefore decrease the dodge speed per axis by ~1/2
                    self.rect[i] += self.movement[i] * 0.8
                    collisions = m.collision_test(self.rect)
                    m.collision_reaction(collisions, self, i)
                    m.boundaries(self.rect)
        else:
            self.dodging = False


# Weapon
class Sword:
    def __init__(self, dim, dmg, knock_back, sprite_dir):
        self.rect = Rect(0, 0, dim[0], dim[1])
        self.swinging = False
        self.dmg = dmg
        self.knock_back_pwr = knock_back

        self.theta = [90, 270]  # range of angles Sword travels in relative to player
        self.frame = 0

        self.animations = {}
        for folder in os.listdir(sprite_dir):
            self.animations[folder] = []
        for folder in os.listdir(sprite_dir):  # opens animation folder using 'sprite_directory'
            for frame in os.listdir(sprite_dir + folder):
                rendered_image = transform.scale(image.load(sprite_dir + folder + '\\' + frame),
                                                 (self.rect[2], self.rect[3]))
                self.animations[folder].append(rendered_image)  # append frames in order of name

        self.swing_sound = mixer.Sound(r'Sounds\Sword\swing_sound.wav')

    def direction(self, player):  # determines animation state and range of swing
        if player.facing == 'right':
            self.theta = [0, 180]
            self.animation_state = "swing_right"
        elif player.facing == 'left':
            self.theta = [180, 360]
            self.animation_state = "swing_left"
        elif player.facing == 'backward':
            self.theta = [270, 450]
            self.animation_state = 'swing_backward'
        elif player.facing == 'forward':
            self.theta = [90, 270]
            self.animation_state = 'swing_forward'

    def swing(self, player):  # controls the rotation of the sword around the player

        if self.swinging and self.theta[0] < self.theta[1]:  # if the sword has not completed its swing path

            radius = 50
            rotation_point = [(player.rect.x + player1.rect[2] / 2), (player.rect.y + player1.rect[3] / 2)]
            self.rect.x, self.rect.y = (rotation_point[0] + sin((pi / 180) * self.theta[0]) * radius - self.rect[2] / 2), \
                                       (rotation_point[1] - cos((pi / 180) * self.theta[0]) * radius - self.rect[3] / 2)
            # moves sword in a semicircular path around the player within the range of values in self.theta

            self.theta[0] += (600 / fps)  # determines rotation speed
            self.animate()

        else:
            self.rect[0], self.rect[1] = 0, 0
            # moves sword hit box off playable screen, so it cannot collide with Enemies
            self.swinging = False
            self.frame = 0

    def animate(self):  # animates sword
        self.frame += 0.45
        if int(self.frame) >= len(self.animations[self.animation_state]):
            # resets sword animation frame after the end of each swing
            self.frame = 0
        screen.blit(self.animations[self.animation_state][int(self.frame)], self.rect)


# Enemy
class Enemy(Entity):  # Child class of Entity, used as parent class for specific enemy types (Slime)
    def __init__(self, hp, sprite_dir, dim, spd, dmg, knock_back_pwr):
        super().__init__(hp, sprite_dir, dim, spd)

        self.knock_back_pwr = knock_back_pwr
        self.dmg = dmg
        self.hp = hp

        self.rect = (Rect(0, 0, dim[0], dim[1]))
        self.theta = 0
        self.movement = [0, 0]
        self.spd = 0
        self.frame = 0

    def load_position(self, m, taken_tiles):  # loads random positions on the grid
        while True:  # loop until a non chosen tile is picked
            rand_tile = random.choice(m.tile_dict['f'][0])  # picks a random 'f' tile on gid
            if rand_tile not in taken_tiles:  # if random tile has already been taken, pick again
                x, y = rand_tile[0], rand_tile[1]
                self.rect.x, self.rect.y = x, y

                return rand_tile


class Slime(Enemy):  # Child class of Enemy. Used as a common enemy to fight
    def __init__(self, hp, sprite_dir, dim, spd, dmg, knock_back_pwr):
        super().__init__(hp, sprite_dir, dim, spd, dmg, knock_back_pwr)
        self.animation_state = 'dash_right'

        self.move_sound = mixer.Sound(r'Sounds\Slime\move_sound.wav')

    def direction(self):
        if self.hp <= 0:
            self.animation_state = 'death'
            self.animation_speed = 0.4

        if self.animation_state != 'death':
            self.animation_speed = 0.1
            if self.movement[0] > 0:
                self.animation_state = 'dash_right'
            elif self.movement[0] < 0:
                self.animation_state = 'dash_left'

    def move(self, p, m, s):
        if not self.knock_back:
            if self.spd <= 0:  # only runs after the slime has stopped
                self.find_theta(p)  # changes direction of next dash
                self.move_sound.play()  # plays 'move_sound' right before next dash
                self.frame = 0
                self.spd = self.max_spd

            # sets the x and y speed dependent on where the Player is relative to Slime
            self.movement[0] = (self.spd * sin(self.theta))
            self.movement[1] = (-self.spd * cos(self.theta))
            self.spd -= 0.1

        elif self.knock_back:
            self.take_knock_back()

        if self.rect.colliderect(s.rect) and not self.invulnerable:  # if Slime collides with Sword (during Sword.swing)
            self.take_damage(s.dmg)  # Slime takes damage
            self.find_theta(p)
            self.spd = s.knock_back_pwr
            self.knock_back = True  # Slime is knocked back

        if self.hp > 0:  # if slime is alive, move.
            for x in range(2):  # moves in each axis, checking for collisions with Map tiles
                self.rect[x] += self.movement[x]
                collisions = m.collision_test(self.rect)
                m.collision_reaction(collisions, self, x)

        m.boundaries(self.rect)
        self.direction()
        self.invulnerable_timer()
        self.health_bar([self.rect.centerx, self.rect[1] - 10], red)
        self.animate(self.animation_speed, [0, 0])


class Menu:  # Used for GUI option menu's
    def __init__(self, buttons, button_text, img, startup):
        self.running = startup  # defines if Menu is running on first startup
        self.text_font = font.SysFont('Helvetica', 25)  # font setup
        self.button_text = button_text
        self.rendered_text = []
        self.menu_img = transform.scale(image.load(r'Sprites\\' + img), (screendim[0], screendim[1]))  # background image
        self.buttons = buttons

        for i, key in enumerate(buttons):
            self.buttons[key] = Rect(buttons[key])
            self.rendered_text.append(self.text_font.render(button_text[i], True, white))  # render text beforehand

    def menu_screen(self):
        screen.blit(self.menu_img, (0, 0))
        for i, key in enumerate(self.buttons):
            text_rect = self.rendered_text[i].get_rect(center=self.buttons[key].center)  # centre text within button
            screen.blit(self.rendered_text[i], text_rect)

        while self.running:
            mouse_pos = mouse.get_pos()
            for event in pygame.event.get():
                for key in self.buttons:
                    if event.type == MOUSEBUTTONUP and self.buttons[key].collidepoint(mouse_pos):
                        # if the cursor is over Menu button
                        if key != 'c':  # 'c' refers to 'controls' Menu
                            self.running = False
                            return key

                        elif key == 'c':
                            return key  # returns pressed button type

                    elif event.type == KEYDOWN:
                        if event.key == K_ESCAPE:  # if the 'esc' key is pressed
                            self.running = False
                            return next(iter(self.buttons))  # return the first key in Menu.buttons

                if event.type == QUIT:
                    quit()  # closes pygame window
            display.update()


class Timer:  # Used to track how long the user takes to beat the game
    def __init__(self):
        self.timer_box = Rect(1280, 550, 150, 250)
        self.text_font = font.SysFont('Helvetica', 25)  # font setup
        self.text_list = []
        self.rendered_text = []
        self.running = False
        with open(r'scores.txt') as scores:
            for line in scores:
                if '\n' in line:
                    line = line.replace('\n', "")  # removes '\n' after every new line
                self.text_list.append(float(line))  # converts each line into a float to be sorted
            scores.close()
        self.text_list.sort()  # sorts each time in order of fastest (lowest) time to slowest (highest) time
        for i in range(3):  # renders the top 3 times
            try:
                self.rendered_text.append(self.text_font.render(str(self.text_list[i]), True, grey))
            except IndexError:
                break

        self.time_since_start = 0

    def run_timer(self):  # starts timer
        if self.running:  # if the timer has been activated:
            self.current_time = str(round((time.get_ticks() + self.time_since_start)/1000, 2))
            # gets time since 'run_timer' has been run (In seconds)
            current_rendered_time = self.text_font.render(("Current:"+self.current_time), True, blue)
            # renders current time in blue
            draw.rect(screen, black, self.timer_box)
            screen.blit(current_rendered_time, current_rendered_time.get_rect(centerx=self.timer_box.centerx,
                                                                              centery=600))
            # blits current time on screen
            for i in range(3):  # blits top 3 scores below current time
                try:
                    screen.blit(self.rendered_text[i], self.rendered_text[i].get_rect(centerx=self.timer_box.centerx,
                                                                                      centery=650 + (50*i)))
                except IndexError:
                    break

    def write_score(self):  # writes current score into file
        if self.running:
            with open(r'scores.txt', 'a') as scores:
                    scores.write('\n'+self.current_time)
            scores.close()


def load_level(level, player):  # used every time a new level is opened
    enemies = []
    taken_tiles = []
    current_map = Map(level[0], [45, 45])
    player.rect.x, player.rect.y = 700, 650  # puts player back into starting position

    for i in range(level[1]):
        enemies.append(Slime(50, r'Sprites\Enemies\Slime\\', [30, 30, 30, 30], 6, 5, 5))
        taken_tiles.append(enemies[i].load_position(current_map, taken_tiles))
    return current_map, enemies


# Defining Menu classes
title_menu = Menu({'s': [620, 450, 200, 75], 't': [620, 520, 200, 75], 'c': [620, 590, 200, 75], 'q': [620, 660, 200, 75]},
                  ["START", "TIMER MODE", "CONTROLS", "QUIT"], "title_screen.jpg", True)

pause_menu = Menu({'r': [620, 450, 200, 75], 'c': [620, 550, 200, 75], 'tm': [620, 650, 200, 75]},
                  ["RESUME", "CONTROLS", "MAIN MENU"], "pause_screen.jpg", False)

death_menu = Menu({'tm': [620, 650, 200, 75]},
                  ["MAIN MENU"], "death_screen.jpg", False)

win_menu = Menu({'tm': [620, 700, 200, 75]},
                ["MAIN MENU"], "win_screen.jpg", False)
win_sound = mixer.Sound(r'Sounds\Player\death_sound.wav')

controls_menu = Menu({'r': [1415, 0, 25, 25]},
                     ["x"], "controls_screen.jpg", False)
# Defining Timer class
timer1 = Timer()


map_list = []
for maps in os.listdir(r'Map_Data'):  # imports map_data and converts to a string
    with open(r'Map_Data\\' + maps) as map_data:
        map_list.append(map_data.read())
    map_data.close()

level = {0: [map_list[0], 1], 1: [map_list[1], 2], 2: [map_list[2], 3], 3: [map_list[3], 4],
         4: [map_list[4], 5], 5: [map_list[5], 6], 6: [map_list[6], 7]}
# format {stage: [current map, number of enemies} ^

# Main Loop
menu_loop = True
game_loop = True

while game_loop:

    if menu_loop:
        mixer.music.load(r'Sounds\Music\menu_music.wav')  # Plays menu music
        mixer.music.play(-1)

    while menu_loop:
        if controls_menu.running:
            menu_choice = controls_menu.menu_screen()

        elif title_menu.running:  # if title menu is running, reset player, sword, and stage
            stage = 0
            player1 = Player(100, r'Sprites\Player\\', [42, 42, 42, 66], 5)
            sword = Sword([30, 30], 25, 10, r'Sprites\Weapons\Sword\\')
            menu_choice = title_menu.menu_screen()
            current_map, enemies = load_level(level[stage], player1)  # loads first level

        elif pause_menu.running:
            menu_choice = pause_menu.menu_screen()

        elif death_menu.running:
            menu_choice = death_menu.menu_screen()

        elif win_menu.running:
            timer1.write_score()  # writes score into 'scores' file if timer is running
            menu_choice = win_menu.menu_screen()

        else:
            menu_choice = None
        if menu_choice == "c":  # if controls option is chosen in Menu
            controls_menu.running = True

        elif menu_choice == "q":  # if quit option is chosen in Menu
            menu_loop = False
            game_loop = False
        elif menu_choice == "tm":  # if main menu option is chosen in Menu
            title_menu.running = True

        elif menu_choice == "s":  # if start option is chosen in Menu
            title_menu.running, pause_menu.running, death_menu.running, win_menu.running, controls_menu.running,\
                timer1.running = False, False, False, False, False, False  # closes all other menus
            menu_loop = False
            mixer.music.load(r'Sounds\Music\game_music.wav')  # plays standard game music
            mixer.music.play(-1)

        elif menu_choice == "r":  # if resume option is chosen in Menu
            title_menu.running, pause_menu.running, death_menu.running, win_menu.running, controls_menu.running, = \
                False, False, False, False, False  # closes all other menus
            menu_loop = False
            mixer.music.load(r'Sounds\Music\game_music.wav')  # plays standard game music
            mixer.music.play(-1)

        elif menu_choice == "t":  # if timer mode option is chosen in Menu
            timer1.time_since_start = -int(time.get_ticks())
            timer1.running = True  # start running timer
            title_menu.running, pause_menu.running, death_menu.running, win_menu.running, controls_menu.running = \
                False, False, False, False, False
            menu_loop = False
            mixer.music.load(r'Sounds\Music\timer_mode_music.wav')  # plays special timer mode music
            mixer.music.play(-1)

    # FPS
    fps = 60
    time.Clock().tick(fps)  # sets fps of game

    # Death condition
    if player1.animation_state == 'death' and player1.frame == 0:
        # if the player is dead and has finished their death animation:
        player1.death_sound.play()  # play death sound
        menu_loop = True
        death_menu.running = True

    # Human Interaction
    for event in pygame.event.get():
        if event.type == QUIT:
            game_loop = False  # breaks loop and ends game

        if event.type == KEYDOWN:  # WASD controls
            if event.key == K_d:
                player1.right = True
            if event.key == K_a:
                player1.left = True
            if event.key == K_s:
                player1.down = True
            if event.key == K_w:
                player1.up = True

            if event.key == K_j and not sword.swinging and not player1.dodging:  # if conditions met: swing sword
                sword.swing_sound.play()
                sword.swinging = True
                sword.direction(player1)

            if event.key == K_SPACE and not player1.dodging:  # if conditions met: Player dodge
                player1.frame = 0
                player1.dodging = True
                player1.invulnerable = True

            if event.key == K_ESCAPE:  # if escape key is pressed, run escape Menu
                pause_menu.running = True
                menu_loop = True
                player1.right, player1.left, player1.down, player1.up = False, False, False, False
                # Must stop player movement as menu has its own game loop

        if event.type == KEYUP:
            if event.key == K_d:
                player1.right = False
            if event.key == K_a:
                player1.left = False
            if event.key == K_s:
                player1.down = False
            if event.key == K_w:
                player1.up = False

    screen.blit(background, (0, 0))  # blit background
    current_map.blit_tiles()

    for enemy in enemies:  # move every enemy with respect to current Map, Player and Sword

        enemy.move(player1, current_map, sword)
        if enemy.animation_state == 'death' and enemy.frame == 0:
            # if Enemy is dead and finished their death animation
            enemies.remove(enemy)  # deletes enemy from level

    if len(enemies) <= 0 and current_map.next_level:
        # if all Enemies have been killed and Player is touching 'e' tile
        stage += 1
        try:
            current_map, enemies = load_level(level[stage], player1)
        except KeyError:  # if KeyError, all levels have been defeated
            win_menu.running = True
            menu_loop = True

    sword.swing(player1)
    player1.move(current_map, enemies)
    timer1.run_timer()

    display.update()
