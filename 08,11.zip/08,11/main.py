import time

import pygame, sys
from pygame import *
from math import *
import random

init()

# window
screendim = [1440, 810]
screen = display.set_mode((screendim[0], screendim[1]))

# colours
white = (255, 255, 255)
red = (255, 0, 0)
turquoise = (49, 129, 138)
pink = (255, 105, 180)

# Background
background = transform.scale(image.load(r'Sprites\\' + 'Background' + '.png'), (screendim[0], screendim[1])).convert()

# Map
# https://pythonprogramming.altervista.org/platform-game-in-detail-part-1/?doing_wp_cron=1655762207.1499760150909423828125

map1 = """                                
                                
   ftttffffffffffffffffffffff   
   fttfffffffffffffffffffffff   
   ftffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
                                
                                """


map2 = """                                
                                
   ttttffffffffffffffffffffff   
   tttfffffffffffffffffffffff   
   ttffffffffffffffffffffffff   
   tfffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff   
   ffffffffffffffffffffffffff  
                                
                                """

map_list = [map1, map2]


class Map:
    def __init__(self, m,   rect_dim):  # self, map, graphical overlay
        self.m = m
        self.tile_dict = {}

        for element in m:
            if element != ' ':
                self.tile_dict[element] = ([], [])

        for y, line in enumerate(self.m.splitlines()):
            for x, c in enumerate(line):
                try:
                    self.tile_dict[c][0].append(Rect(x * rect_dim[0], y * rect_dim[1], rect_dim[0], rect_dim[1]))
                    sprite = transform.scale(image.load(r'Sprites\Tiles\\' + c + '.png'), (rect_dim[0], rect_dim[1]))
                    self.tile_dict[c][1].append(sprite)

                except:
                    pass

    def blit_tiles(self):
        for key in self.tile_dict:
            for i, sprite in enumerate(self.tile_dict[key][1]):
                if key != 'f':
                    screen.blit(sprite, (self.tile_dict[key][0][i][0], self.tile_dict[key][0][i][1]))  # sprite = sprite, l[0][i] = rect

    def collision_test(self, rect):
        collisions = []

        for key in self.tile_dict:
            for i, tile in enumerate(self.tile_dict[key][0]):
                if rect.colliderect(tile):
                    collisions.append([key, i])
        return collisions

    def collision_reaction(self, collisions, movement, rect, axis):
        for collision in collisions:
            key = collision[0]
            i = collision[1]
            tile = self.tile_dict[key][0]

            if key == "t":

                if axis == 0:
                    if movement[0] > 0:
                        rect.right = tile[i].left
                    if movement[0] < 0:
                        rect.left = tile[i].right

                elif axis == 1:
                    if movement[1] > 0:
                        rect.bottom = tile[i].top
                    if movement[1] < 0:
                        rect.top = tile[i].bottom

    def boundaries(self, rect):
        xrange = [170, 1235]
        yrange = [100, 670]
        if rect.x > xrange[1]:
            rect.x = xrange[1]

        elif rect.x < xrange[0]:
            rect.x = xrange[0]

        if rect.y > yrange[1]:
            rect.y = yrange[1]

        elif rect.y < yrange[0]:
            rect.y = yrange[0]


# Player
class Player:
    def __init__(self, dim, spd, hp):
        self.dim = dim
        self.rect = Rect(700, 650, dim[0], dim[1])
        self.colour = turquoise
        self.left, self.right, self.up, self.down = False, False, False, False
        self.facing = 180
        self.movement = [0, 0]
        self.speed = spd

        self.hp = hp
        self.max_hp = hp
        self.hp_bar = Rect(10, 10, hp, 10)
        self.invulnerable = time.get_ticks()
        self.invulnerable_duration = 600

    def move(self, m):
        self.movement = [0, 0]

        if self.right:
            self.movement[0] += self.speed
        if self.left:
            self.movement[0] -= self.speed
        if self.up:
            self.movement[1] -= self.speed
        if self.down:
            self.movement[1] += self.speed

        for i in range(2):
            self.rect[i] += self.movement[i]

            collisions = m.collision_test(self.rect)
            m.collision_reaction(collisions, self.movement, self.rect, i)

    def blit_player(self):
        if abs(self.invulnerable - time.get_ticks()) > self.invulnerable_duration:
            draw.rect(screen, self.colour, self.rect)
        else:
            draw.rect(screen, red, self.rect)
        draw.rect(screen, red, self.hp_bar)

    def player_enemy_collision(self, enemy, i):
        if abs(self.invulnerable - time.get_ticks()) > self.invulnerable_duration:
            if self.rect.colliderect(enemy.rect[i]):
                self.hp -= enemy.dmg
                self.hp_bar[2] -= enemy.dmg
                self.invulnerable = time.get_ticks()


player1 = Player([40, 40], 8, 100)


# Weapon
class Sword:
    def __init__(self, dim, dmg):
        self.dim = dim
        self.rect = Rect(0, 0, dim[0], dim[1])
        self.swinging = False
        self.theta = [player1.facing - 90, player1.facing + 90]  # rendered direction, final position
        self.dmg = dmg
        self.knockback_pwr = 10

    def swing(self, player):

        if self.swinging and self.theta[0] < self.theta[1]:

            radius = 50
            rotation_point = [(player.rect.x + player1.dim[0]/2), (player.rect.y + player1.dim[1]/2)]
            self.rect.x, self.rect.y = (rotation_point[0] + sin((pi/180) * self.theta[0])*radius - self.dim[0]/2),  \
                                       (rotation_point[1] - cos((pi/180) * self.theta[0])*radius - self.dim[1]/2)

            self.theta[0] += 500/fps
            draw.rect(screen, red, self.rect)

        else:
            self.rect[0], self.rect[1] = 0, 0  # moves sword hitbox off playable screen
            self.swinging = False


sword = Sword([30, 30], 10)


# Enemy
class Enemy:
    def __init__(self, hp, dim, sprite):
        self.dim = dim
        self.hp = [hp]
        self.sprite = sprite
        self.rect = []
        self.theta = [0]
        self.movement = [[0, 0]]
        self.knockback = [False]
        self.spd = [0]

    def load_position(self, m, n):
        taken_tiles = []

        for i in range(n):
            while True:
                rand_tile = random.choice(m.tile_dict['f'][0])
                if rand_tile not in taken_tiles:
                    break

            x, y = rand_tile[0], rand_tile[1]
            self.rect.append(Rect(x, y, self.dim[0], self.dim[1]))
            self.hp.append(self.hp[0])
            self.theta.append(self.theta[0])
            self.movement.append(self.movement[0])
            self.spd.append(self.spd[0])
            self.knockback.append(self.knockback[0])
            taken_tiles.append(rand_tile)

    def blit_enemy(self):
        for item in self.rect:
            screen.blit(self.sprite, (item[0], item[1]))

    def enemy_collision(self, i, axis):

        for x, enemy in enumerate(self.rect):
            if i != x:
                if self.rect[i].colliderect(enemy):

                    if axis == 0:
                        if self.movement[i][0] > 0:
                            self.rect[i].right = enemy.left
                        if self.movement[i][0] < 0:
                            self.rect[i].left = enemy.right

                    elif axis == 1:
                        if self.movement[i][1] > 0:
                            self.rect[i].bottom = enemy.top
                        if self.movement[i][1] < 0:
                            self.rect[i].top = enemy.bottom

    def find_theta(self, rect, i, p):
        deltax = (p.rect[0] - rect[0])
        deltay = (p.rect[1] - rect[1])

        if deltax == 0:  # Zero Division error
            deltax += 1
        if deltay == 0:
            deltay += 1

        self.theta[i] = atan2(deltax, -deltay)
        self.theta[i] %= 2 * pi

    def get_hit(self, rect, i, m):
        if self.spd[i] <= 0:
            self.knockback[i] = False

        for x in range(2):
            rect[x] += self.movement[i][x]
            self.enemy_collision(i, x)
            collisions = m.collision_test(rect)
            m.collision_reaction(collisions, self.movement[i], rect, x)


class Slime(Enemy):
    def __init__(self, hp, dim, sprite, spd, dmg):
        super().__init__(hp, dim, sprite)

        self.max_spd = spd
        self.dmg = dmg

    def move(self, p, m, s):

        for i, rect in enumerate(self.rect):

            self.spd[i] -= 0.2

            if self.spd[i] <= 0:  # Only allows slimes to change direction after stopping
                self.find_theta(rect, i, p)

            if rect.colliderect(s.rect) and not self.knockback[i]:
                self.find_theta(rect, i, p)
                self.spd[i] = s.knockback_pwr
                self.knockback[i] = True

            if self.knockback[i]:
                self.movement[i][0] = (self.spd[i] * sin(self.theta[i])) * -1
                self.movement[i][1] = (-self.spd[i] * cos(self.theta[i])) * -1
                self.get_hit(rect, i, m)

            else:
                # movement
                self.movement[i][0] = (self.spd[i] * sin(self.theta[i]))
                self.movement[i][1] = (-self.spd[i] * cos(self.theta[i]))
                for x in range(2):
                    rect[x] += self.movement[i][x]
                    self.enemy_collision(i, x)
                    collisions = m.collision_test(rect)
                    m.collision_reaction(collisions, self.movement[i], rect, x)

            m.boundaries(rect)
            p.player_enemy_collision(self, i)

            if self.spd[i] <= 0:  # must be at end to break knockback loop
                self.spd[i] = self.max_spd


slime_hp = 50
slime_dim = [40, 40]
slime_sprite = transform.scale(image.load(r'Sprites\Enemies\slime.png'), (slime_dim[0], slime_dim[1]))
slime_speed = 6
slime_dmg = 10
slime = Slime(slime_hp, slime_dim, slime_sprite, slime_speed, slime_dmg)
num_slimes = 3


# Main Loop
game_loop = True
stage = 0
pause = False
map_list[stage] = Map(map_list[stage], [45, 45])
slime.load_position(map_list[stage], num_slimes)
while game_loop:
    # FPS
    fps = 60
    time.Clock().tick(fps)

    # Human Interaction
    for event in pygame.event.get():
        if event.type == QUIT:    
            game_loop = False

        if event.type == KEYDOWN:
            if event.key == K_RIGHT:
                player1.right = True
            if event.key == K_LEFT:
                player1.left = True
            if event.key == K_DOWN:
                player1.down = True
            if event.key == K_UP:
                player1.up = True

            if event.key == K_SPACE and not sword.swinging:
                sword.swinging = True
                sword.theta = [player1.facing - 90, player1.facing + 90]

            if event.key == K_0:
                stage += 1
                map_list[stage] = Map(map_list[stage], [45, 45])
                slime.load_position(map_list[stage], num_slimes)

            if event.key == K_ESCAPE:
                pause = True
                while pause:
                    screen.fill(red)
                    if event.type == KEYUP:
                        if event.key == K_ESCAPE:
                            pause = False

        if event.type == KEYUP:
            if event.key == K_RIGHT:
                player1.right = False
            if event.key == K_LEFT:
                player1.left = False
            if event.key == K_DOWN:
                player1.down = False
            if event.key == K_UP:
                player1.up = False

    screen.blit(background, (0, 0))
    map_list[stage].blit_tiles()

    slime.move(player1, map_list[stage], sword)
    slime.blit_enemy()

    player1.move(map_list[stage])
    player1.blit_player()

    sword.swing(player1)

    map_list[stage].boundaries(player1.rect)

    display.update()
