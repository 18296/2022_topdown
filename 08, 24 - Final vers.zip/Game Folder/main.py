import pygame
from pygame import *
from pygame import mixer
from math import *
import random
import os

init()

# window
screendim = [1440, 810]
screen = display.set_mode((screendim[0], screendim[1]))
display.set_caption('SLIPPERY 7')
display.set_icon(image.load(r'Sprites\game_icon.jpg'))


# colours
white = (255, 255, 255)
red = (255, 0, 0)
yellow = (255, 255, 0)

# Background
background = transform.scale(image.load(r'Sprites\\' + 'Background' + '.png'), (screendim[0], screendim[1])).convert()


# Map
class Map:
    def __init__(self, m, rect_dim):
        self.m = m
        self.tile_dict = {}
        self.next_level = False

        for element in m:
            if element != ' ':
                self.tile_dict[element] = ([], [])

        for y, line in enumerate(self.m.splitlines()):
            for x, c in enumerate(line):
                try:
                    self.tile_dict[c][0].append(Rect(x * rect_dim[0], y * rect_dim[1], rect_dim[0], rect_dim[1]))
                    sprite = transform.scale(image.load(r'Sprites\Tiles\\' + c + '.png'), (rect_dim[0], rect_dim[1]))
                    self.tile_dict[c][1].append(sprite)

                except:
                    pass

    def blit_tiles(self):
        for key in self.tile_dict:
            for i, sprite in enumerate(self.tile_dict[key][1]):
                if key != 'f':
                    screen.blit(sprite, (
                        self.tile_dict[key][0][i][0], self.tile_dict[key][0][i][1]))  # sprite = sprite, l[0][i] = rect

    def collision_test(self, rect):
        collisions = []

        for key in self.tile_dict:
            for i, tile in enumerate(self.tile_dict[key][0]):
                if rect.colliderect(tile):
                    collisions.append([key, i])
        return collisions

    def collision_reaction(self, collisions, object, axis):
        self.next_level = False
        for collision in collisions:
            key = collision[0]
            i = collision[1]
            tile = self.tile_dict[key][0]

            if key == "h":
                object.take_damage(999)

            if key == "l":
                object.take_damage(10)

            if key == "t":

                if axis == 0:
                    if object.movement[0] > 0:
                        object.rect.right = tile[i].left
                    if object.movement[0] < 0:
                        object.rect.left = tile[i].right

                elif axis == 1:
                    if object.movement[1] > 0:
                        object.rect.bottom = tile[i].top
                    if object.movement[1] < 0:
                        object.rect.top = tile[i].bottom

            if key == "e":
                self.next_level = True

    def boundaries(self, rect):
        xrange = [170, 1235]
        yrange = [90, 647]
        if rect.x > xrange[1]:
            rect.x = xrange[1]

        elif rect.x < xrange[0]:
            rect.x = xrange[0]

        if rect.y > yrange[1]:
            rect.y = yrange[1]

        elif rect.y < yrange[0]:
            rect.y = yrange[0]


# Player
class Player:
    def __init__(self, dim, spd, hp):
        self.rect = Rect(700, 650, dim[0], dim[1])
        self.left, self.right, self.up, self.down = False, False, False, False
        self.facing = 'backward'
        self.movement = [0, 0]
        self.speed = spd
        self.dodging = False

        self.hp = hp
        self.hp_bar = Rect(10, 10, hp * 2, 10)
        self.hp_bar_vfx = Rect(10, 10, hp * 2, 10)
        self.invulnerable = True
        self.invulnerable_duration = 30

        self.frame = 0

        self.animation_state = 'idle_backward'
        self.animations = {}
        for folder in os.listdir(r'Sprites\Player'):
            self.animations[folder] = []
            for frame in os.listdir(r'Sprites\Player\\' + folder):
                rendered_image = transform.scale(image.load(r'Sprites\Player\\' + folder + '\\' + frame),
                                                 (self.rect[2], self.rect[3] + 24))
                self.animations[folder].append(rendered_image)

        self.death_sound = mixer.Sound(r'Sounds\Player\death_sound.wav')

    def move(self, m, enemies):
        if not self.dodging and self.animation_state != 'death':
            self.movement = [0, 0]

            if self.right:
                self.movement[0] += self.speed
            if self.left:
                self.movement[0] -= self.speed
            if self.up:
                self.movement[1] -= self.speed
            if self.down:
                self.movement[1] += self.speed

            for i in range(2):
                self.rect[i] += self.movement[i]

                collisions = m.collision_test(self.rect)
                m.collision_reaction(collisions, self, i)
                m.boundaries(self.rect)

            self.player_enemy_collision(enemies)

        elif self.dodging and self.animation_state != 'death':
            self.dodge(m)

        self.direction()

    def animate(self):
        self.health_bar()
        self.frame += len(self.animations[self.animation_state])/60
        if int(self.frame) >= len(self.animations[self.animation_state]):
            self.frame = 0

        screen.blit(self.animations[self.animation_state][int(self.frame)], (self.rect[0], self.rect[1] - 24))

    def take_damage(self, amount):

        if not self.invulnerable:
            self.hp -= amount
            self.invulnerable = True

    def player_enemy_collision(self, enemies):
        self.invulnerable_timer()
        for enemy in enemies:
            if self.rect.colliderect(enemy.rect):
                self.take_damage(enemy.dmg)

    def health_bar(self):
        self.hp_bar[2] = self.hp * 2
        if self.hp_bar_vfx[2] > self.hp_bar[2]:
            self.hp_bar_vfx[2] -= 0.05

        draw.rect(screen, yellow, self.hp_bar_vfx)
        draw.rect(screen, red, self.hp_bar)

    def invulnerable_timer(self):
        if self.invulnerable:
            self.invulnerable_duration -= 1

        if self.invulnerable_duration <= 0:
            self.invulnerable_duration = 30
            self.invulnerable = False

    def direction(self):
        if self.hp <= 0:
            self.animation_state = 'death'

        if self.animation_state != 'death':

            if self.movement[1] > 0 and self.movement[0] == 0:
                if self.dodging:
                    self.animation_state = 'dodge_forward'
                else:
                    self.animation_state = 'walk_forward'
                self.facing = 'forward'

            elif self.movement[1] < 0 and self.movement[0] == 0:
                if self.dodging:
                    self.animation_state = 'dodge_backward'
                else:
                    self.animation_state = 'walk_backward'
                self.facing = 'backward'

            elif self.movement[0] > 0:
                if self.dodging:
                    self.animation_state = 'dodge_right'
                else:
                    self.animation_state = 'walk_right'
                    self.animation_state = 'walk_right'
                self.facing = 'right'
            elif self.movement[0] < 0:
                if self.dodging:
                    self.animation_state = 'dodge_left'
                else:
                    self.animation_state = 'walk_left'
                self.facing = 'left'

            if self.facing == 'forward' and self.movement == [0, 0]:
                self.animation_state = 'idle_forward'

            elif self.facing == 'backward' and self.movement == [0, 0]:
                self.animation_state = 'idle_backward'

            elif self.facing == 'right' and self.movement == [0, 0]:
                self.animation_state = 'idle_right'

            elif self.facing == 'left' and self.movement == [0, 0]:
                self.animation_state = 'idle_left'  # onedrive corrupted 'idle_left' folder

    def dodge(self, m):
        self.invulnerable_timer()
        if self.invulnerable:
            for i in range(2):
                self.rect[i] += self.movement[i] * 1.5
                collisions = m.collision_test(self.rect)
                m.collision_reaction(collisions, self, i)
                m.boundaries(self.rect)
        else:
            self.dodging = False


# Weapon
class Sword:
    def __init__(self, dim, dmg, knockback):
        self.rect = Rect(0, 0, dim[0], dim[1])
        self.swinging = False
        self.dmg = dmg
        self.knockback_pwr = knockback

        self.theta = [90, 270]
        self.frame = 0

        self.animations = {}
        for folder in os.listdir(r'Sprites\Weapons\Sword'):
            self.animations[folder] = []
        for folder in os.listdir(r'Sprites\Weapons\Sword'):
            for frame in os.listdir(r'Sprites\Weapons\Sword\\' + folder):
                rendered_image = transform.scale(image.load(r'Sprites\Weapons\Sword\\' + folder + '\\' + frame),
                                                 (self.rect[2], self.rect[3]))
                self.animations[folder].append(rendered_image)

        self.swing_sound = mixer.Sound(r'Sounds\Sword\swing_sound.wav')

    def direction(self, player):
        if player.facing == 'right':
            self.theta = [0, 180]
            self.animation_state = "swing_right"
        elif player.facing == 'left':
            self.theta = [180, 360]
            self.animation_state = "swing_left"
        elif player.facing == 'backward':
            self.theta = [270, 450]
            self.animation_state = 'swing_backward'
        elif player.facing == 'forward':
            self.theta = [90, 270]
            self.animation_state = 'swing_forward'

    def swing(self, player):

        if self.swinging and self.theta[0] < self.theta[1]:

            radius = 50
            rotation_point = [(player.rect.x + player1.rect[2] / 2), (player.rect.y + player1.rect[3] / 2)]
            self.rect.x, self.rect.y = (rotation_point[0] + sin((pi / 180) * self.theta[0]) * radius - self.rect[2] / 2), \
                                       (rotation_point[1] - cos((pi / 180) * self.theta[0]) * radius - self.rect[3] / 2)

            self.theta[0] += (600 / fps)
            self.animate()

        else:
            self.rect[0], self.rect[1] = 0, 0  # moves sword hitbox off playable screen
            self.swinging = False
            self.frame = 0

    def animate(self):
        self.frame += 0.45
        if int(self.frame) >= len(self.animations[self.animation_state]):
            self.frame = 0
        screen.blit(self.animations[self.animation_state][int(self.frame)], self.rect)


# Enemy
class Enemy:
    def __init__(self, hp, dim, sprite, dmg):
        self.dmg = dmg
        self.hp = hp
        self.sprite = transform.scale(image.load(r'Sprites\Enemies\\' + sprite), (dim[0], dim[1]))
        self.rect = (Rect(0, 0, dim[0], dim[1]))
        self.theta = 0
        self.movement = [0, 0]
        self.knockback = False
        self.spd = 0
        self.frame = 0

    def take_damage(self, amount):
        self.hp -= amount

    def load_position(self, m, taken_tiles):
        while True:
            rand_tile = random.choice(m.tile_dict['f'][0])
            if rand_tile not in taken_tiles:
                x, y = rand_tile[0], rand_tile[1]
                self.rect.x, self.rect.y = x, y

                return rand_tile

    def enemy_collision(self, axis, e):
        for i, enemy in enumerate(e):
            if enemy != self:
                if self.rect.colliderect(enemy):

                    if axis == 0:
                        if self.movement[0] > 0:
                            self.rect.right = enemy.left
                        if self.movement[0] < 0:
                            self.rect.left = enemy.right

                    elif axis == 1:
                        if self.movement[1] > 0:
                            self.rect.bottom = enemy.top
                        if self.movement[1] < 0:
                            self.rect.top = enemy.bottom

    def find_theta(self, p):
        deltax = (p.rect[0] - self.rect[0])
        deltay = (p.rect[1] - self.rect[1])

        if deltax == 0:  # Zero Division error
            deltax += 1
        if deltay == 0:
            deltay += 1

        self.theta = atan2(deltax, -deltay)
        self.theta %= 2 * pi

    def get_hit(self, m):

        if self.spd <= 0:
            self.knockback = False

        for x in range(2):
            self.rect[x] += self.movement[x]
            # self.enemy_collision(x)
            collisions = m.collision_test(self.rect)
            m.collision_reaction(collisions, self, x)


class Slime(Enemy):
    def __init__(self, hp, dim, sprite, max_spd, dmg):
        super().__init__(hp, dim, sprite, dmg)
        self.max_spd = max_spd

        self.animations = {}
        self.animation_state = 'dash_right'
        for folder in os.listdir(r'Sprites\Enemies\Slime'):
            self.animations[folder] = []
        for folder in os.listdir(r'Sprites\Enemies\Slime'):
            for frame in os.listdir(r'Sprites\Enemies\Slime\\' + folder):
                rendered_image = transform.scale(image.load(r'Sprites\Enemies\Slime\\' + folder + '\\' + frame),
                                                 (self.rect[2], self.rect[3]))
                self.animations[folder].append(rendered_image)

        self.move_sound = mixer.Sound(r'Sounds\Slime\move_sound.wav')

    def direction(self):
        if self.hp <= 0:
            self.animation_state = 'death'

        if self.animation_state != 'death':
            if self.movement[0] > 0:
                self.animation_state = 'dash_right'
            elif self.movement[0] < 0:
                self.animation_state = 'dash_left'

    def move(self, p, m, s):

        self.spd -= 0.1

        if self.spd <= 0:  # Only allows slimes to change direction after stopping
            self.find_theta(p)

        if self.rect.colliderect(s.rect) and not self.knockback:
            self.hp -= s.dmg
            self.find_theta(p)
            self.spd = s.knockback_pwr
            self.knockback = True

        if self.knockback:
            self.movement[0] = (self.spd * sin(self.theta)) * -1
            self.movement[1] = (-self.spd * cos(self.theta)) * -1
            self.get_hit(m)

        else:
            # movement
            self.movement[0] = (self.spd * sin(self.theta))
            self.movement[1] = (-self.spd * cos(self.theta))
            for x in range(2):
                self.rect[x] += self.movement[x]
                collisions = m.collision_test(self.rect)
                m.collision_reaction(collisions, self, x)

        m.boundaries(self.rect)

        if self.spd <= 0:
            self.move_sound.play()
            self.frame = 0
            self.spd = self.max_spd
        self.direction()

    def animate(self):
        self.frame += 0.18
        if int(self.frame) >= len(self.animations[self.animation_state]):
            self.frame = 0

        screen.blit(self.animations[self.animation_state][int(self.frame)], (self.rect[0], self.rect[1]))


class Menu:
    def __init__(self, buttons, button_text, img, startup):
        self.running = startup
        self.text_font = font.SysFont('Helvetica', 25)
        self.button_text = button_text
        self.rendered_text = []
        self.menu_img = transform.scale(image.load(r'Sprites\\' + img), (screendim[0], screendim[1]))
        self.buttons = buttons

        for i, key in enumerate(buttons):
            self.buttons[key] = Rect(buttons[key])
            self.rendered_text.append(self.text_font.render(button_text[i], True, white))

    def menu_screen(self):
        screen.blit(self.menu_img, (0, 0))
        for i, key in enumerate(self.buttons):
            text_rect = self.rendered_text[i].get_rect(center=self.buttons[key].center)
            screen.blit(self.rendered_text[i], text_rect)

        while self.running:
            mouse_pos = mouse.get_pos()
            for event in pygame.event.get():
                for key in self.buttons:
                    if event.type == MOUSEBUTTONUP and self.buttons[key].collidepoint(mouse_pos):

                        if key != 'c':
                            self.running = False
                            return key

                        elif key == 'c':
                            return key

                    elif event.type == KEYDOWN:
                        if event.key == K_ESCAPE:
                            self.running = False
                            return next(iter(self.buttons))

                if event.type == QUIT:
                    quit()
            display.update()


def load_level(level, player):
    enemies = []
    taken_tiles = []
    current_map = Map(level[0], [45, 45])
    player.rect.x, player.rect.y = 700, 650

    for i in range(level[1]):
        enemies.append(Slime(50, [40, 40], 'slime.png', 6, 10))

        taken_tiles.append(enemies[i].load_position(current_map, taken_tiles))

    return current_map, enemies


title_menu = Menu({'s': [620, 450, 200, 75], 'c': [620, 550, 200, 75], 'q': [620, 650, 200, 75]},
                  ["START", "CONTROLS", "QUIT"], "title_screen.jpg", True)

pause_menu = Menu({'s': [620, 450, 200, 75], 'c': [620, 550, 200, 75], 'tm': [620, 650, 200, 75]},
                  ["RESUME", "CONTROLS", "MAIN MENU"], "pause_screen.jpg", False)

death_menu = Menu({'tm': [620, 650, 200, 75]},
                  ["MAIN MENU"], "death_screen.jpg", False)

win_menu = Menu({'tm': [620, 700, 200, 75]},
                ["MAIN MENU"], "win_screen.jpg", False)

controls_menu = Menu({'s': [1415, 0, 25, 25]},
                     ["x"], "controls_screen.jpg", False)


map_list = []
for maps in os.listdir(r'Map_Data'):
    with open(r'Map_Data\\' + maps) as map_data:
        map_list.append(map_data.read())

level = {0: [map_list[0], 1], 1: [map_list[1], 2], 2: [map_list[2], 3], 3: [map_list[3], 4],
         4: [map_list[4], 5], 5: [map_list[5], 6], 6: [map_list[6], 7]}

# Main Loop
menu_loop = True
game_loop = True

while game_loop:

    while menu_loop:
        mixer.music.load(r'Sounds\Music\menu_music.wav')
        mixer.music.play(-1)
        if controls_menu.running:
            menu_choice = controls_menu.menu_screen()

        elif title_menu.running:
            stage = 0
            player1 = Player([42, 42], 5, 200)
            sword = Sword([30, 30], 20, 5)
            menu_choice = title_menu.menu_screen()
            current_map, enemies = load_level(level[stage], player1)

        elif pause_menu.running:
            menu_choice = pause_menu.menu_screen()

        elif death_menu.running:
            menu_choice = death_menu.menu_screen()

        elif win_menu.running:
            menu_choice = win_menu.menu_screen()

        else:
            menu_choice = None
        if menu_choice == "c":
            controls_menu.running = True

        elif menu_choice == "q":
            menu_loop = False
            game_loop = False
        elif menu_choice == "tm":
            title_menu.running = True
        elif menu_choice == "s":
            title_menu.running, pause_menu.running, death_menu.running, win_menu.running, controls_menu.running = \
                False, False, False, False, False
            menu_loop = False
            mixer.music.load(r'Sounds\Music\game_music.wav')
            mixer.music.play(-1)

    # FPS
    fps = 60
    time.Clock().tick(fps)

    # Death condition
    if player1.animation_state == 'death' and player1.frame == 0:
        player1.death_sound.play()
        menu_loop = True
        death_menu.running = True

    # Human Interaction
    for event in pygame.event.get():
        if event.type == QUIT:
            game_loop = False

        if event.type == KEYDOWN:
            if event.key == K_d:
                player1.right = True
            if event.key == K_a:
                player1.left = True
            if event.key == K_s:
                player1.down = True
            if event.key == K_w:
                player1.up = True

            if event.key == K_j and not sword.swinging and not player1.dodging:
                sword.swing_sound.play()
                sword.swinging = True
                sword.direction(player1)

            if event.key == K_SPACE and not player1.dodging:
                player1.frame = 0
                player1.dodging = True
                player1.invulnerable = True

            if event.key == K_ESCAPE:
                pause_menu.running = True
                menu_loop = True
                player1.right, player1.left, player1.down, player1.up = False, False, False, False

        if event.type == KEYUP:
            if event.key == K_d:
                player1.right = False
            if event.key == K_a:
                player1.left = False
            if event.key == K_s:
                player1.down = False
            if event.key == K_w:
                player1.up = False

    screen.blit(background, (0, 0))
    current_map.blit_tiles()

    for enemy in enemies:

        enemy.move(player1, current_map, sword)
        enemy.animate()

        if enemy.animation_state == 'death' and enemy.frame == 0:

            enemies.remove(enemy)

    if len(enemies) <= 0 and current_map.next_level:
        stage += 1
        try:
            current_map, enemies = load_level(level[stage], player1)

        except KeyError:
            win_menu.running = True
            menu_loop = True

    sword.swing(player1)
    player1.move(current_map, enemies)
    player1.animate()

    display.update()
