import pygame, sys
from pygame import *
from math import *
import random

init()

# window
screendim = [1440, 810]
screen = display.set_mode((screendim[0], screendim[1]))

# colours
white = (255, 255, 255)
red = (255, 0, 0)
turquoise = (49, 129, 138)
pink = (255, 105, 180)

# Background
background = transform.scale(image.load(r'Sprites\\' + 'Background' + '.png'), (screendim[0], screendim[1]))
screen.blit(background, (0, 0))

# Map
# https://pythonprogramming.altervista.org/platform-game-in-detail-part-1/?doing_wp_cron=1655762207.1499760150909423828125


# map1 = """tttttttttttttttttttt
# l                  r
# l                  r
# l                  r
# l        ss        r
# l                  r
# l      ssssss      r
# l                  r
# l                  r
# l         s        r
# l                  r
# l     ssssssss     r
# l                  r
# l     ss    ss     r
# bbbbbbbbbbbbbbbbbbbb
# """

# map1 = """tttttttttttttttttttttttttttttttt
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# t                              t
# tttttttttttttttttttttttttttttttt"""

map1 = """tttttttttttttttttttttttttttttttt
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tffffffffffffftfffffffffffffffft
tffffffffffffftfffffffffffffffft
tffffffffffffftfffffffffffffffft
tffffffffffffftfffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tfffffffffffffffffffffffffffffft
tttttttttttttttttttttttttttttttt"""


class Map:
    def __init__(self, m,   rect_dim):  # self, map, graphical overlay
        self.m = m
        self.tile_dict = {}

        for element in m:
            if element != ' ':
                self.tile_dict[element] = ([], [])

        for y, line in enumerate(self.m.splitlines()):
            for x, c in enumerate(line):
                try:
                    self.tile_dict[c][0].append(Rect(x * rect_dim[0], y * rect_dim[1], rect_dim[0], rect_dim[1]))
                    sprite = transform.scale(image.load(r'Sprites\Tiles\\' + c + '.png'), (rect_dim[0], rect_dim[1]))
                    self.tile_dict[c][1].append(sprite)

                except:
                    pass

    def init_tiles(self):
        for l in self.tile_dict.values():
            for i, sprite in enumerate(l[1]):
                screen.blit(sprite, (l[0][i][0], l[0][i][1]))  # sprite = sprite, l[0][i] = rect

    def collision_test(self, rect):
        collisions = []

        for key in self.tile_dict:
            for i, tile in enumerate(self.tile_dict[key][0]):
                if rect.colliderect(tile):
                    collisions.append([key, i])
        return collisions

    def collision_reaction(self, collisions, movement, rect, axis):
        for collision in collisions:
            key = collision[0]
            i = collision[1]
            tile = self.tile_dict[key][0]
            image = self.tile_dict[key][1]

            if key == "f":
                try:
                    for x in range(2):
                        screen.blit(image[i], (tile[i - x][0], tile[i - x][1]))
                        screen.blit(image[i], (tile[i + x][0], tile[i + x][1]))

                except IndexError:
                    break

            elif key == "t":

                if axis == 0:
                    if movement[0] > 0:
                        rect.right = tile[i].left
                    if movement[0] < 0:
                        rect.left = tile[i].right

                elif axis == 1:
                    if movement[1] > 0:
                        rect.bottom = tile[i].top
                    if movement[1] < 0:
                        rect.top = tile[i].bottom


map1 = Map(map1, [45, 45])
map1.init_tiles()


# Player
class Player:
    def __init__(self, dim):
        self.dim = dim
        self.rect = Rect(50, 50, dim[0], dim[1])
        self.colour = turquoise
        self.left, self.right, self.up, self.down = False, False, False, False
        self.facing = 180
        self.movement = [0, 0]
        self.speed = 15

    def move(self, m):
        self.movement = [0, 0]

        if self.right:
            self.movement[0] += self.speed
        if self.left:
            self.movement[0] -= self.speed
        if self.up:
            self.movement[1] -= self.speed
        if self.down:
            self.movement[1] += self.speed

        for i in range(2):
            self.rect[i] += self.movement[i]

            collisions = m.collision_test(self.rect)
            m.collision_reaction(collisions, self.movement, self.rect, i)

    def blit_player(self):
        draw.rect(screen, self.colour, self.rect)

    def direction(self):  # all directions are in radians

        if self.movement[0] > 0 and self.movement[1] == 0:
            self.facing = 90

        if self.movement[0] < 0 and self.movement[1] == 0:
            self.facing = 270

        if self.movement[0] == 0 and self.movement[1] > 0:
            self.facing = 180

        if self.movement[0] == 0 and self.movement[1] < 0:
            self.facing = 360

        elif self.movement[0] > 0 and self.movement[1] > 0:
            self.facing = 135

        elif self.movement[0] > 0 > self.movement[1]:
            self.facing = 45

        elif self.movement[0] < 0 < self.movement[1]:
            self.facing = 225

        elif self.movement[0] < 0 and self.movement[1] < 0:
            self.facing = 315


player1 = Player([40, 40])


# Weapon
class Sword:
    def __init__(self, dim):
        self.dim = dim
        self.rect = Rect(0, 0, dim[0], dim[1])
        self.swinging = False
        self.theta = [player1.facing - 90, player1.facing + 90]  # rendered direction, final position

    def swing(self, player):

        if self.swinging and self.theta[0] < self.theta[1]:

            radius = 60
            rotation_point = [(player.rect.x + player1.dim[0]/2), (player.rect.y + player1.dim[1]/2)]
            self.rect.x, self.rect.y = (rotation_point[0] + sin((pi/180) * self.theta[0])*radius - self.dim[0]/2),  \
                                       (rotation_point[1] - cos((pi/180) * self.theta[0])*radius - self.dim[1]/2)
    
            draw.rect(screen, red, self.rect)

            self.theta[0] += 500/fps

        else:
            self.swinging = False
            

sword = Sword([10, 10])


# Enemy
class Enemy():
    def __init__(self, hp, dim, sprite):
        self.dim = dim
        self.hp = hp
        self.sprite = sprite
        self.rect = []
        self.theta = 0
        self.movement = [0, 0]

    def load_position(self, m, n):
        for i in range(n):
            rand_tile = random.choice(m.tile_dict['f'][0])
            x, y = rand_tile[0], rand_tile[1]
            self.rect.append(Rect(x, y, self.dim[0], self.dim[1]))

    def blit_enemy(self):
        for item in self.rect:
            screen.blit(self.sprite, (item[0], item[1]))


class Slime(Enemy):
    def move(self, p, spd, m):
        for rect in self.rect:
            deltax = (rect[0] - p.rect[0])
            deltay = (rect[1] - p.rect[1])

            if deltax == 0:
                deltax += 1
            if deltay == 0:
                deltay += 1

            self.theta = atan(abs(deltay/deltax))
            self.movement[0] = (spd * cos(self.theta)) * (-deltax / abs(deltax))
            self.movement[1] = (spd * sin(self.theta)) * -(deltay / abs(deltay))

            rect[0] += self.movement[0]
            collisions = m.collision_test(rect)
            m.collision_reaction(collisions, self.movement, rect, 0)

            rect[1] += self.movement[1]
            collisions = m.collision_test(rect)
            m.collision_reaction(collisions, self.movement, rect, 1)


slime_hp = 50
slime_dim = [10, 10]
slime_sprite = transform.scale(image.load(r'Sprites\Enemies\slime.png'), (40, 40))
slime = Slime(slime_hp, slime_dim, slime_sprite)

num_slimes = 1
slime.load_position(map1, num_slimes)

# Main Loop
x = 0
game_loop = True
while game_loop:
    # FPS
    fps = 60
    time.Clock().tick(fps)

    # Human Interaction
    for event in pygame.event.get():
        if event.type == QUIT:    
            game_loop = False

        if event.type == KEYDOWN:
                if event.key == K_RIGHT:
                    player1.right = True
                if event.key == K_LEFT:
                    player1.left = True
                if event.key == K_DOWN:
                    player1.down = True
                if event.key == K_UP:
                    player1.up = True

                if event.key == K_SPACE and not sword.swinging:
                    sword.swinging = True
                    sword.theta = [player1.facing - 90, player1.facing + 90]

        if event.type == KEYUP:
            if event.key == K_RIGHT:
                player1.right = False
            if event.key == K_LEFT:
                player1.left = False
            if event.key == K_DOWN:
                player1.down = False
            if event.key == K_UP:
                player1.up = False

    player1.move(map1)
    player1.direction()
    player1.blit_player()
    sword.swing(player1)

    slime.move(player1, 4, map1)
    slime.blit_enemy()

    display.update()
